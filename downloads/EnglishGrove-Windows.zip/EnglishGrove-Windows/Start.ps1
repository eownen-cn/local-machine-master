﻿$ErrorActionPreference = 'Stop'
$port = 5173
$path = Join-Path $PSScriptRoot 'EnglishGrove.html'
$body = [System.IO.File]::ReadAllBytes($path)
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $port)
try { $listener.Start() } catch { Write-Host "Port 5173 is unavailable. Close the other app and try again."; exit 1 }
Write-Host "English Grove is running. Keep this window open."
Write-Host "This computer: http://localhost:5173"
Write-Host "Phone/tablet: connect to the SAME Wi-Fi, then use a LAN address below:"
try {
 Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { Write-Host ("  http://" + $_.IPAddress + ":5173") }
} catch { Write-Host "Run ipconfig to find your Wi-Fi IPv4 address." }
Write-Host "If Windows Firewall asks, allow access on PRIVATE networks only."
Write-Host "Local demo only. No account or cross-device progress sync."
Start-Process 'http://localhost:5173'
try {
 while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
   $client.ReceiveTimeout = 5000
   $client.SendTimeout = 5000
   $stream = $client.GetStream()
   $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
   $request = $reader.ReadLine()
   if (-not $request) { continue }
   $total = 0
   do { $line = $reader.ReadLine(); $total += $line.Length; if ($total -gt 16384) { throw 'Headers too large' } } while ($line)
   $method = ($request -split ' ')[0]
   if ($method -ne 'GET' -and $method -ne 'HEAD') {
    $header = "HTTP/1.1 405 Method Not Allowed`r`nContent-Length: 0`r`nConnection: close`r`n`r`n"
    $bytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($bytes, 0, $bytes.Length)
    continue
   }
   $header = "HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
   $bytes = [System.Text.Encoding]::ASCII.GetBytes($header)
   $stream.Write($bytes, 0, $bytes.Length)
   if ($method -eq 'GET') { $stream.Write($body, 0, $body.Length) }
   $stream.Flush()
  } catch { Write-Host 'A request was interrupted; server is still running.' }
  finally { $client.Close() }
 }
} finally { $listener.Stop() }
